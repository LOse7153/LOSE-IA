package com.loseia.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val gold = Color.rgb(255, 198, 42)
    private val blue = Color.rgb(20, 123, 255)
    private val black = Color.rgb(5, 7, 10)
    private val card = Color.rgb(13, 20, 29)
    private val white = Color.WHITE
    private val muted = Color.rgb(169, 176, 186)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildDashboard()
    }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(12, 8, 12, 8)
        }
    }

    private fun cardView(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            background = GradientDrawable().apply {
                setColor(card)
                cornerRadius = 22f
                setStroke(1, Color.rgb(54, 70, 88))
            }
        }
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                setColor(gold)
                cornerRadius = 18f
            }
            setOnClickListener { onClick() }
        }
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 24)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val logo = ImageView(this).apply {
            setImageResource(com.loseia.app.R.drawable.logo_lose_ia)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        header.addView(logo, LinearLayout.LayoutParams(82, 82))

        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(text("LOSE IA", 28f, gold, true))
        titleBox.addView(text("Intelligence artificielle • Football", 12f, muted))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header)

        content.addView(text("MATCHS DU JOUR", 22f, gold, true))

        val days = listOf("LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE")
        val dayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        days.forEach { day ->
            val b = Button(this).apply {
                text = day
                textSize = 9f
                setTextColor(if (day == "LUNDI") Color.BLACK else white)
                background = GradientDrawable().apply {
                    setColor(if (day == "LUNDI") gold else Color.rgb(24, 31, 42))
                    cornerRadius = 14f
                }
                setOnClickListener {
                    Toast.makeText(this@MainActivity, "$day sélectionné — les matchs réels seront chargés par la source sportive autorisée.", Toast.LENGTH_SHORT).show()
                }
            }
            dayRow.addView(b, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(2, 2, 2, 2) })
        }
        content.addView(dayRow)

        val info = cardView()
        info.addView(text("MISE À JOUR AUTOMATIQUE", 15f, gold, true))
        info.addView(text("Prévu pour fonctionner 24 h/24 et 7 j/7. Les matchs doivent venir d'une source sportive/API autorisée.", 13f, muted))
        content.addView(info)

        val matches = listOf(
            "Match réel — source à connecter" to "Analyser avec LOSE IA",
            "Match réel — source à connecter" to "Analyser avec LOSE IA",
            "Match réel — source à connecter" to "Analyser avec LOSE IA"
        )
        matches.forEach { (name, action) ->
            val c = cardView()
            c.addView(text(name, 16f, white, true))
            c.addView(text("Aucun faux score : les équipes et statistiques seront affichées uniquement après réception de données réelles.", 12f, muted))
            val btn = button(action) {
                Toast.makeText(this, "Connexion aux données réelles à configurer.", Toast.LENGTH_SHORT).show()
            }
            c.addView(btn, LinearLayout.LayoutParams(-1, 54))
            content.addView(c, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 0) })
        }

        val live = cardView()
        live.addView(text("🔴 LIVE    🎮 VIRTUELS", 19f, white, true))
        live.addView(text("Deux espaces séparés pour éviter toute confusion entre matchs réels et jeux virtuels.", 12f, muted))
        content.addView(live, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 0) })

        val ai = cardView()
        ai.addView(text("🤖 IA TIPSTER    •    🎯 TIPS GOS", 19f, gold, true))
        ai.addView(text("Score exact probable • 1N2 • Over/Under • Corners • Cartons • Tirs cadrés • 1re/2e mi-temps • Confiance", 13f, white))
        content.addView(ai, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 0) })

        val history = cardView()
        history.addView(text("📈 HISTORIQUE", 19f, white, true))
        history.addView(text("Prédiction → résultat réel → mesure de performance.", 13f, muted))
        content.addView(history, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 0) })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(9, 12, 17))
        }
        listOf("Accueil", "Matchs", "Stats", "Historique", "Compte").forEachIndexed { i, label ->
            val b = Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(if (i == 0) gold else white)
                setBackgroundColor(Color.TRANSPARENT)
            }
            nav.addView(b, LinearLayout.LayoutParams(0, 64, 1f))
        }
        root.addView(nav)

        setContentView(root)
    }
}
